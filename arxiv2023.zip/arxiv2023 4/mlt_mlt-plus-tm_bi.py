#!/usr/bin/env python
# coding: utf-8

# Run for MLT and MLT-plus-TM for B-C (Binary classifier) on Detecting Out of Policy Speech (OOPS) content datasets.
# OOPS datasets include: 1) CAD dataset and 2) HateCheck test suite.
# MLT: Our proposed meta-learning combiner that combines individual models
# MLT-plus-TM: TM (threshold-moving) is applied after MLT

# **Datasets and training**
# - Use CAD in training MLT and best thresholds for TM. Then do transfer learning on HateCheck dataset: use HateCheck to test the final performance.
# - Input to MLT is predicted probabilities on 'Hateful' class resulted from binary classifier in each individual model Bigbird, BERT, BERTWeet, Bloom and Xlnet.
# - Outputs from MLT are combined predicted probabilities from individual models.
# - Train best threshold using combined predicted probabilites from MLT.
# - Applied TM with the best threshold on HateCheck and get MLT-plus-TM performance result.

## First command to run to ensure reproducible results
start_seed = 42
from numpy.random import seed
seed(start_seed)
import tensorflow as tf
tf.random.set_seed(start_seed)

import pandas as pd
import numpy as np

import os
import sys
import glob
import itertools
from operator import itemgetter

from numpy import argmax
from numpy import arange
import matplotlib.pyplot as plt
from numpy import mean
from numpy import std

from sklearn.metrics import accuracy_score,  classification_report, f1_score
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras import regularizers

## Data locations
base_dir = './data/'

# Individual model data locations
bi_prefix = 'bi/'
bert_dir = "./bert/" + bi_prefix
bertweet_dir = "./btweet/" + bi_prefix
bigbird_dir = "./bigbird/" + bi_prefix
bloom_dir = "./bloom/" + bi_prefix
xlnet_dir = "./xlnet/" + bi_prefix

hc_data = base_dir + "hackCheck_data/" + "hatecheck_final_ACL.csv"


## Individual models participating combiners
model_dic = {
    'm1': "bigbird",
    'm2': "bert",
    'm3': "bertweet",
    "m4": "bloom",
    "m5": "xlnet"
}

## Individual model data locations
model_locs = {
    'm1': bigbird_dir,
    'm2': bert_dir,
    'm3': bertweet_dir,
    "m4": bloom_dir,
    "m5": xlnet_dir
}
models = ['m1', 'm2', 'm3', 'm4', 'm5']

## Load all Y true values 
# "non-hateful" column value is 0, "hateful" column value is 1
ht_column, nht_column = '1', '0'
labels = ['non_hateful', 'hateful']


# Load predicted probabilities resulted from binary and multilabel classifiers for all individual models

# Load CAD Dev, Test and HC predicted prob files for all permutations
prob_file_pattern = '_prob'
dev_file_pattern = '_dev'
test_file_pattern = '_te'
hc_file_pattern = '_hc'
label_file_pattern = '_label'
csv_file_pattern = '*.csv'


# keep track of individual model run history. 
# Only run a single model once
global_individual_cad_run_list = list()
global_individual_hc_run_list = list()

for model in models:
    # results for all individual runs
    globals() [f"{model}_cad_results"] = list() # CAD dataset
    globals() [f"{model}_hc_results"] = list() # HateCheck dataset

# global Log information holder
contents = []

## Display and log a content
def log_content(content):
    contents.append(content)
    if isinstance(content, list):
        for i in content:
            print(i)
    else:
        print(content)

## Get metric performance
## y_true: true values
## y_pred: predicted values
## return: metric results
def get_performance(y_true, y_pred):
    classi_report_dict = classification_report(y_true, y_pred, zero_division=1, digits=4, output_dict=True)
    classi_report_str = classification_report(y_true, y_pred, zero_division=1, digits=4)
    acc = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred, average ='macro')
    roc = 0.0 # for multi-class, this has no value
    return [[classi_report_dict, classi_report_str], acc, f1, roc]


## Send performance results to a buffer for later display and log
## header: Starting header for a task
## y_true: true y values
## y_pred: predicted y values
def log_performance(header, y_true, y_pred):
    # Set decimal format
    np.set_printoptions(formatter={'float': lambda x: "{0:0.4f}".format(x)})
    local_contents = list()
    
    local_contents.append(header)
    
    classi_reports, acc, f1, roc = get_performance(y_true, y_pred)
    
    acc_str = 'Accuracy is >'
    local_contents.append(acc_str)
    local_contents.append(acc)
    
    f1_str = "Macro F1 score is >"
    local_contents.append(f1_str)
    local_contents.append(f1)
    
    classification_report_str = "Classification results are >"
    local_contents.append(classification_report_str)
    local_contents.append(classi_reports[1])
    
    log_content(local_contents)
    return  [classi_reports, acc, f1, roc]


def get_participating_model_performance_1(file_pair, test_prob, cad_test_y_true, contents):
    header = "The participated model file pair are \n{}\n{}".format(file_pair[0], file_pair[1])
    print(header)
    contents.append(header)
    cad_test_y_pred = np.round(test_prob)
    header = "Performance for this model:"
    log_performance(header, cad_test_y_true, cad_test_y_pred, contents)

## Get a linear combiner model. Input shape equals to number of particupating models.
## Each column represents predicted probability values of one class from each participating model
## model_num: number of participating models
## return: linear combiner
def get_linear_combiner(model_num):
    model = Sequential()
    # uses 'tanh' activation
    model.add(Dense(1, activation='tanh',
            kernel_regularizer=regularizers.L1L2(l1=1e-5, l2=1e-4),
            bias_regularizer=regularizers.l2(1e-4),
            activity_regularizer=regularizers.l2(1e-5),
            input_shape=(model_num,), name="hidden1_layer"))
    model.add(Dense(1, activation="sigmoid", name="prediction_layer"))

    model.summary()
    return model

def get_history (history):
    # list all data in history
    print(history.history.keys())
    history.history
    
    
    # summarize history for loss
    plt.ylabel('Loss')
    plt.xlabel('Epochs')
    plt.plot(history.history['loss'], color='blue', label='train')
    if "val_loss" in history.history:
        plt.plot(history.history['val_loss'], color='orange', label='val')
        plt.title('Train vs Validation Loss')
    else:
        plt.title('Train loss')
    plt.legend()
    plt.show()
        
        
    # Summarize history for accuracy
    plt.ylabel('Accuracy')
    plt.xlabel('Epochs')
    plt.plot(history.history['accuracy'], color='blue', label='train')
    if "val_accuracy" in history.history:
        plt.plot(history.history['val_accuracy'], color='orange', label='val')
        plt.title('Train vs Validation Accuracy')
    else:
        plt.title('Train accuracy')
    plt.legend()
    plt.show()

## Train a linear combiner for target class
## model: model to train
## train_data: train data including train and validation data
## hyper_paras: model hypermarameters
def train_linear_combiner(model, data, hyper_params):
    train_X, train_y = data[0], data[1]
    val_X, val_y = data[2], data[3]
    
    loss, metrics, epoch, batch_size, l_rate = hyper_params[0], hyper_params[1],hyper_params[2],hyper_params[3],hyper_params[4]
    
    opt = Adam(learning_rate=l_rate)
    model.compile(optimizer=opt, 
          loss=loss,
          metrics=metrics)
    
    history = model.fit(train_X, train_y,
#     validation_split=0.3, # Used in tuning
    validation_data=(val_X, val_y),
    epochs=epoch,
    batch_size=batch_size,
    shuffle=True,
    verbose = 0)
    
    #get_history (history)
    
    return model


# Apply threshold to positive probabilities to create labels
def to_labels(pos_probs, threshold):
	return (pos_probs >= threshold).astype('int')

## calculate best f1 score for one class. ytrue and yhat are one dimension data.
## The metric to maximize is macro F1. 
## average_type: 'binary' or 'macro'. Use 'binary' in CAD, use 'macro' in Hatecheck
def get_best_pr(ytrue, y_pred_prob, average_type):
    # define thresholds
    from numpy import arange
    thresholds = arange(0.00001, 1, 0.001)
    # evaluate each threshold
    scores = [f1_score(ytrue, to_labels(y_pred_prob, t), average=average_type) for t in thresholds]
    # get best threshold
    ix = argmax(scores)
    
    return thresholds[ix]


# Get mean and std on specified metrics for a list of runs
# model_name: name of the model
# results: list of run results
# labels: labels of classes in the classifier
# metrics: specified metrics, such as accuracy, recall, precision, various F1 scores, etc
def get_mean_on_metrics(model_name, results, labels, metrics, showPlot=True):
    local_contents = list()
    log_str = "Performance for {}:".format(model_name)
    local_contents.append(log_str)
   
    # Get average mean of accuracy
    accs = list()
    # Get average mean of macro F1
    mf1s = list()
    for i in range(len(results)):
        accs.append(results[i][1])
        mf1s.append(results[i][2])
    local_contents.append(show_mean_score_std(accs, 'Accuracy', showPlot))
    local_contents.append(show_mean_score_std(mf1s, 'Macro F1', showPlot))
    
    local_contents.append("\nPerformance in individual classes:")
    [per_class_metrics, all_class_metrics] = metrics[0], metrics[1]
    # Get label classes
    keys = results[0][0][0].keys()
    label_dict = {}
    classes = list(keys)[0:len(labels)]
    
    # Get per class metric performance
    i = 0
    for label in labels:
        label_dict[label] = classes[i]
        i = i + 1
    
    # Get list for holding all performance to avverage for each class
    for label in labels:
        for metric in per_class_metrics:
            new_metric = metric.replace('-', '_')
            globals()[f"{label}_{new_metric}_list"] = list()
    
    # Get performance result for each class
    for i in range(len(results)):
        for label in labels:
            for metric in per_class_metrics:
                new_metric = metric.replace('-', '_')
                eval(f"{label}_{new_metric}_list").append(results[i][0][0].get(label_dict.get(label)).get(metric))    
    # Display result
    for label in labels:
        for metric in per_class_metrics:
            new_metric = metric.replace('-', '_')
            show_mean_score_std(eval(f"{label}_{new_metric}_list"), label + '_' + metric, showPlot)

    # Get list for holding all performance to avverage
    for metric in all_class_metrics:
        [average_type, average_metric] = metric[0], metric[1]
        new_average_type = average_type.replace(' ', '_')
        new_average_metric = average_metric.replace('-', '_')
        globals()[f"{new_average_type}_{new_average_metric}_list"] = list()
        
    # Get all class metric performance
    for i in range(len(results)):
        for metric in all_class_metrics:
            [average_type, average_metric] = metric[0], metric[1]
            new_average_type = average_type.replace(' ', '_')
            new_average_metric = average_metric.replace('-', '_')
            eval(f"{new_average_type}_{new_average_metric}_list").append(results[i][0][0].get(average_type).get(average_metric))
    
    # Display result
    for metric in all_class_metrics:
        [average_type, average_metric] = metric[0], metric[1]
        new_average_type = average_type.replace(' ', '_')
        new_average_metric = average_metric.replace('-', '_')
        show_mean_score_std(eval(f"{new_average_type}_{new_average_metric}_list"), average_type + '_' + average_metric, showPlot)
    
    return local_contents

## After apply individual threshold values in each class, combine all class as one final prediction
## orig_pred_prob: original predicted probabilities
## thresholds: trained optimal threshold values to apply in each class
## return new_pre: numpy array of final predictions after thresholds are applied and combined
def get_pred_after_threshold(original_pred_prob, thresholds):
    new_pred_all = []
    for i in range(len(thresholds)):
        globals() [f"new_pred_c{i}"] = to_labels(eval(f"original_pred_prob[:,i]"), eval(f"thresholds[i]"))
        new_pred_all.append(eval(f"new_pred_c{i}").T)
#         new_pred_c0 = to_labels(original_pred_prob[:,0], thresholds[0])
#         new_pred_c1 = to_labels(original_pred_prob[:,1], thresholds[1])
#         new_pred_c2 = to_labels(original_pred_prob[:,2], thresholds[2])
#         new_pred_c3 = to_labels(original_pred_prob[:,3], thresholds[3])
#         new_pred_c4 = to_labels(original_pred_prob[:,4], thresholds[4])
    df_pred_all_columns = pd.DataFrame(data=new_pred_all)
    return df_pred_all_columns.to_numpy().T

# Display mean accuracy and std
def show_mean_score_std(scores, score_label, showPlot=True):
    local_contents = list()
    # print summary
    log_str = '{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format(score_label, mean(scores), std(scores), len(scores))

    local_contents.append(log_str)
    if showPlot:
        # box and whisker plots of results
        plt.boxplot(scores)
        plt.show()
    return local_contents

# Output contents to a file
def write_to_file():
    f_name = "MLT_TM_B_C_results.txt"
    with open(f_name, 'w') as f:
        for item in contents:
            if isinstance(item, list):
                for i in item:
                    f.write(str(i))
                    f.write(os.linesep)
            else:
                f.write(str(item))
                f.write(os.linesep)


# Get y_true values from CAD train, test and HateCheck
def get_y_true():
    # Get y_true files
    dev_label_file = None
    test_label_file = None
    hc_label_file = None

    for file_name in sorted(glob.glob(bert_dir + csv_file_pattern)):
        if (dev_file_pattern + label_file_pattern) in file_name:
            if dev_label_file == None:
                dev_label_file = file_name
        if (test_file_pattern + label_file_pattern) in file_name:
            if test_label_file == None:
                test_label_file = file_name
        if (hc_file_pattern + label_file_pattern) in file_name:
            if hc_label_file == None:
                hc_label_file = file_name

    # Get y_true values
    df_dev_y_true = pd.read_csv(dev_label_file)
    dev_y_true = df_dev_y_true[df_dev_y_true.columns[0:2]]

    df_te_y_true = pd.read_csv(test_label_file)
    test_y_true = df_te_y_true[df_te_y_true.columns[0:2]]

    df_hc_y_true = pd.read_csv(hc_label_file)
    hc_y_true = df_hc_y_true[df_hc_y_true.columns[0:2]]

    return [dev_y_true, test_y_true, hc_y_true]

def run_bi_combiner(models):
    data_dic = {} # file name as key, df_data as value
    dirs = list()
    model_info = list()
    
    # Get all dev and test prob file names
    dev_file_list = list()
    test_file_list = list()
    hc_file_list = list()
    
    for model in models:
        dirs.append(model_locs.get(model))
        model_info.append(model_dic.get(model))

    content = "Participated models are {}".format(model_info)
    log_content(content)

    # Load all predicted probs
    all_model_probs = list() # it has probability data and the file where it is from

    for directory in dirs:
        prob_file_path = directory
        dev_files = list() 
        test_files = list()
        hc_files = list()
        dev_probs = list()
        test_probs = list()
        hc_probs = list()
        
        for file_name in sorted(glob.glob(prob_file_path + csv_file_pattern)):
            if (dev_file_pattern + prob_file_pattern) in file_name:
                dev_files.append(file_name)
            if (test_file_pattern + prob_file_pattern) in file_name:
                test_files.append(file_name)
            if (hc_file_pattern + prob_file_pattern) in file_name:
                hc_files.append(file_name)
            df_data = pd.read_csv(file_name)
            df_data.drop(columns=df_data.columns[-1],  axis=1,  inplace=True)
            data_dic.update({file_name: df_data})
            if dev_file_pattern in file_name:
                dev_probs.append([df_data, file_name])
            if test_file_pattern in file_name:
                test_probs.append([df_data, file_name])
            if hc_file_pattern in file_name:
                hc_probs.append([df_data, file_name])
        dev_file_list.append(dev_files)
        test_file_list.append(test_files)
        hc_file_list.append(hc_files)
        all_model_probs.append([dev_probs, test_probs, hc_probs])

    # Create all permutations from paticipated individual models
    d_p = list(itertools.product(*dev_file_list))
    t_p = list(itertools.product(*test_file_list))
    h_p = list(itertools.product(*hc_file_list))
    
    hc_results = list() # hatecheck MLT
    hc_results_tm = list() # hatecheck MLT-plus-TM

    cad_results = list() #  cad MLT
    cad_results_tm = list() #  CAD MLT-plus-TM

    content = "There will be {} combining runs".format(len(d_p))
    log_content(content)

    # Loop through each run
    for i in range(len(d_p)):
        log_content("Run at {}/{} ({})".format((i+1), len(d_p), model_info))
        train_probs = list()
        test_probs = list()
        hc_probs = list()
        # loop through individual models
        for model in range(len(models)):
            d_file = d_p[i][model]
            # First column is non-hateful, second column is hateful
            train_prob = data_dic.get(d_file).iloc[:,1] # get hateful column
            train_probs.append(train_prob) 
            t_file = t_p[i][model]
            test_prob = data_dic.get(t_file).iloc[:,1]
            test_probs.append(test_prob)
            h_file = h_p[i][model]
            hc_prob = data_dic.get(h_file).iloc[:,1]
            hc_probs.append(hc_prob)
            
            # get CAD individual model runs
            individual_cad_results = globals() [f"{models[model]}_cad_results"]
            if t_file not in global_individual_cad_run_list:
                global_individual_cad_run_list.append(t_file)
                this_result = get_performance(np.round(test_prob), test_ht_y_true)
                individual_cad_results.append(this_result)

            # get HateCheck individual model runs
            individual_hc_results = globals() [f"{models[model]}_hc_results"]
            if h_file not in global_individual_hc_run_list:
                global_individual_hc_run_list.append(h_file)
                this_result = get_performance(np.round(hc_prob), hc_ht_y_true)
                individual_hc_results.append(this_result)
         
        # get probs from all paticipating models for current run
        probs = [train_probs, test_probs, hc_probs]
        ht_y_true = [dev_ht_y_true, test_ht_y_true, hc_ht_y_true]
        
        train_mlt_data_X = pd.DataFrame(probs[0]).T
        test_mlt_data_X = pd.DataFrame(probs[1]).T
        hc_mlt_data_X = pd.DataFrame(probs[2]).T
        
        # Get a linear combiner MLT
        model_linear = get_linear_combiner(len(models))
        
        
        ## Train MLT on ht_column and treshold moving values
        ht_linear_model = train_linear_combiner(model_linear, [train_mlt_data_X,             dev_ht_y_true, test_mlt_data_X, test_ht_y_true], hyper_params)
        train_pred_prob = ht_linear_model.predict(train_mlt_data_X)
       
        log_content("    MLT weights: {}".format(((ht_linear_model.get_weights()[0]).T)))
        log_content("    bias: {}".format(ht_linear_model.get_weights()[1]))
        # Train threshold using train data!!!
        trained_threshold = get_best_pr(dev_ht_y_true, train_pred_prob, 'macro')
        log_content("    The trained TM value is {}".format(trained_threshold))


        header_text = "--------MLT results on CAD test -------------"
        test_pred_prob = ht_linear_model.predict(test_mlt_data_X)
        test_pred = np.round(test_pred_prob)
        cad_results.append(log_performance(header_text, test_ht_y_true, test_pred))
        header_text = "-------MLT-plus-TM results on CAD ---------"
        after_TM_pred= get_pred_after_threshold(test_pred_prob, [trained_threshold])
        cad_results_tm.append(log_performance(header_text, test_ht_y_true, after_TM_pred))


        header_text = "-------------MLT results on HateCheck--------------"
        hc_pred_prob = ht_linear_model.predict(hc_mlt_data_X)
        hc_pred = np.round(hc_pred_prob)
        # output MLT prediction on hatecheck 
        df_hc_pred = pd.DataFrame(hc_pred)
        df_hc_pred.to_csv('./mlt_pred_hc/mlt_pred_hc_' + str(i+1) + '.csv')
        hc_results.append(log_performance(header_text, hc_ht_y_true, hc_pred))

        header_text = "------MLT-plus-TM results on HateCheck-----"
        after_TM_pred= get_pred_after_threshold(hc_pred_prob, [trained_threshold])
        # output MLT prediction on hatecheck 
        df_hc_pred = pd.DataFrame(after_TM_pred)
        df_hc_pred.to_csv('./mlt_tm_pred_hc/mlt_tm_pred_hc_' + str(i+1) + '.csv')
        hc_results_tm.append(log_performance(header_text, hc_ht_y_true, after_TM_pred))
   
       
    for model in models:
        # HateCheck individual results
        hc_individual_run = globals() [f"{model}_hc_results"]
        hc_individual_mf1s = [hc_individual_run[i][2] for i in range(len(hc_individual_run))]
        hc_individual_accs = [hc_individual_run[i][1] for i in range(len(hc_individual_run))]
        log_content("\nPerformance for HateCheck {}:".format(model_dic[model]))
        log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.                format('Accuracy', mean(hc_individual_accs), std(hc_individual_accs),                       len(hc_individual_accs)))
        log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.                format('Macro F1', mean(hc_individual_mf1s), std(hc_individual_mf1s),                        len(hc_individual_mf1s)))

        
    
    # Results for HateCheck per category
    nht_recalls = [hc_results[i][0][0].get('0').get('recall') for i in range(len(d_p))]
    nht_f1s = [hc_results[i][0][0].get('0').get('f1-score') for i in range(len(d_p))]
    ht_recalls = [hc_results[i][0][0].get('1').get('recall') for i in range(len(d_p))]
    ht_f1s = [hc_results[i][0][0].get('1').get('f1-score') for i in range(len(d_p))]
    nht_recalls_tm = [hc_results_tm[i][0][0].get('0').get('recall') for i in range(len(d_p))]
    nht_f1s_tm = [hc_results_tm[i][0][0].get('0').get('f1-score') for i in range(len(d_p))]
    ht_recalls_tm = [hc_results_tm[i][0][0].get('1').get('recall') for i in range(len(d_p))]
    ht_f1s_tm = [hc_results_tm[i][0][0].get('1').get('f1-score') for i in range(len(d_p))]

    hc_mf1s = [hc_results[i][2] for i in range(len(d_p))]
    hc_accs = [hc_results[i][1] for i in range(len(d_p))]
    hc_accmf1 = [(hc_mf1s[i] + hc_accs[i]) for i in range(len(d_p))]

    hc_mf1s_tm = [hc_results_tm[i][2] for i in range(len(d_p))]
    hc_accs_tm = [hc_results_tm[i][1] for i in range(len(d_p))]
    hc_accmf1_tm = [(hc_mf1s_tm[i] + hc_accs_tm[i]) for i in range(len(d_p))]
    
    cad_mf1s = [cad_results[i][2] for i in range(len(d_p))]
    cad_accs = [cad_results[i][1] for i in range(len(d_p))]
    cad_accmf1 = [(cad_mf1s[i] + cad_accs[i]) for i in range(len(d_p))]

    cad_mf1s_tm = [cad_results_tm[i][2] for i in range(len(d_p))]
    cad_accs_tm = [cad_results_tm[i][1] for i in range(len(d_p))]
    cad_accmf1_tm = [(cad_mf1s_tm[i] + cad_accs_tm[i]) for i in range(len(d_p))]
    
    log_content('\nPerformance for HateCheck MLT:')
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Accuracy', mean(hc_accs), std(hc_accs), len(hc_accs)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Macro F1', mean(hc_mf1s), std(hc_mf1s), len(hc_mf1s)))
    log_content("\nPerformance for HateCheck MLT per category:")
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Hateful recall', mean(ht_recalls), std(ht_recalls), len(ht_recalls)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Hateful F1', mean(ht_f1s), std(ht_f1s), len(ht_f1s)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Non-hateful recall', mean(nht_recalls), std(nht_recalls), len(nht_recalls)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Non-hateful F1', mean(nht_f1s), std(nht_f1s), len(nht_f1s)))
   
    log_content('\nPerformance for HateCheck MLT-plus-TM:')
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Accuracy', mean(hc_accs_tm), std(hc_accs_tm), len(hc_accs_tm)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Macro F1', mean(hc_mf1s_tm), std(hc_mf1s_tm), len(hc_mf1s_tm)))
    log_content("\nPerformance for HateCheck MLT-plus-TM per category:")
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Hateful recall', mean(ht_recalls_tm), std(ht_recalls_tm), len(ht_recalls_tm)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('HateCheck F1', mean(ht_f1s_tm), std(ht_f1s_tm), len(ht_f1s_tm)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Non-hateful recall', mean(nht_recalls_tm), std(nht_recalls_tm), len(nht_recalls_tm)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Non-hateful F1', mean(nht_f1s_tm), std(nht_f1s_tm), len(nht_f1s_tm)))
  
    for model in models:
        # CAD individual results
        cad_individual_run = globals() [f"{model}_cad_results"]
        cad_individual_mf1s = [cad_individual_run[i][2] for i in range(len(cad_individual_run))]
        cad_individual_accs = [cad_individual_run[i][1] for i in range(len(cad_individual_run))]
        log_content("\nPerformance for CAD {}:".format(model_dic[model]))
        log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Accuracy', mean(cad_individual_accs), std(cad_individual_accs), len(cad_individual_accs)))
        log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Macro F1', mean(cad_individual_mf1s), std(cad_individual_mf1s), len(cad_individual_mf1s)))
   
    # Results for CAD per category
    cad_nht_recalls = [cad_results[i][0][0].get('0').get('recall') for i in range(len(d_p))]
    cad_nht_f1s = [cad_results[i][0][0].get('0').get('f1-score') for i in range(len(d_p))]
    cad_ht_recalls = [cad_results[i][0][0].get('1').get('recall') for i in range(len(d_p))]
    cad_ht_f1s = [cad_results[i][0][0].get('1').get('f1-score') for i in range(len(d_p))]
    cad_nht_recalls_tm = [cad_results_tm[i][0][0].get('0').get('recall') for i in range(len(d_p))]
    cad_nht_f1s_tm = [cad_results_tm[i][0][0].get('0').get('f1-score') for i in range(len(d_p))]
    cad_ht_recalls_tm = [cad_results_tm[i][0][0].get('1').get('recall') for i in range(len(d_p))]
    cad_ht_f1s_tm = [cad_results_tm[i][0][0].get('1').get('f1-score') for i in range(len(d_p))]
    
    log_content("\nPerformance for CAD MLT:")
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Accuracy', mean(cad_accs), std(cad_accs), len(cad_accs)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Macro F1', mean(cad_mf1s), std(cad_mf1s), len(cad_mf1s)))
    log_content("\nPerformance for CAD MLT per category:")
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Hateful recall', mean(cad_ht_recalls), std(cad_ht_recalls), len(cad_ht_recalls)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Hateful F1', mean(cad_ht_f1s), std(cad_ht_f1s), len(cad_ht_f1s)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Non-hateful recall', mean(cad_nht_recalls), std(cad_nht_recalls), len(cad_nht_recalls)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Non-hateful F1', mean(cad_nht_f1s), std(cad_nht_f1s), len(cad_nht_f1s)))
    log_content("\nPerformance for CAD MLT-plus-TM:")
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Accuracy', mean(cad_accs_tm), std(cad_accs_tm), len(cad_accs_tm)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Macro F1', mean(cad_mf1s_tm), std(cad_mf1s_tm), len(cad_mf1s_tm)))
    log_content("\nPerformance for CAD MLT-plus-TM per category:")
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Hateful recall', mean(cad_ht_recalls_tm), std(cad_ht_recalls_tm), len(cad_ht_recalls_tm)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('HateCheck F1', mean(cad_ht_f1s_tm), std(cad_ht_f1s_tm), len(cad_ht_f1s_tm)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Non-hateful recall', mean(cad_nht_recalls_tm), std(cad_nht_recalls_tm), len(cad_nht_recalls_tm)))
    log_content('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format('Non-hateful F1', mean(cad_nht_f1s_tm), std(cad_nht_f1s_tm), len(cad_nht_f1s_tm)))    
    
    plt.figure(figsize=(10,15))
    plt.title('Performance in each combination')

    plt.ylabel('Macro F1 scores')
    plt.xlabel('Run #')
    x_points = range(0, len(hc_results))

    plt.scatter(x_points, hc_mf1s, color='red', label='hc')
    plt.scatter(x_points, hc_mf1s_tm, color='pink', label='hc_tm')
    plt.scatter(x_points, cad_mf1s, color='orange', label='cad')
    plt.scatter(x_points, cad_mf1s_tm, color='blue', label='cad_tm')
    plt.legend()
    plt.show()
    
    return [mean(hc_accmf1), mean(hc_accmf1_tm), mean(cad_accmf1), mean(cad_accmf1_tm),            mean(hc_mf1s), mean(hc_accs), mean(hc_mf1s_tm), mean(hc_accs_tm), mean(cad_mf1s), mean(cad_accs), mean(cad_mf1s_tm), mean(cad_accs_tm)]


hc_combiner_results = dict()
hc_tm_combiner_results = dict()
cad_combiner_results = dict()
cad_tm_combiner_results = dict()
dev_y_true, test_y_true, hc_y_true = get_y_true()
# Get hateful column true values
dev_ht_y_true = dev_y_true.iloc[:,1]
test_ht_y_true = test_y_true.iloc[:,1]
hc_ht_y_true = hc_y_true.iloc[:,1]

loss = 'binary_crossentropy'
metrics = ['accuracy',tf.keras.metrics.Precision(),tf.keras.metrics.Recall()]
epoch = 50
batch_size = 64
l_rate = 0.0039

hyper_params = [loss, metrics, epoch, batch_size, l_rate]

combine_count = 0
for L in range(len(models) + 1):
    for subset in itertools.combinations(models, L):
        if (len(subset) > 1):
            combine_count = combine_count + 1
log_content("There will be {} number of combinations. Each combination will have multiple runs.".format(combine_count))

for L in range(len(models) + 1):
    for subset in itertools.combinations(models, L):
        if (len(subset) > 1):
            [v1, v2, v3, v4, v5,v6,v7,v8,v9,v10,v11,v12] = run_bi_combiner(subset)
            hc_combiner_results.update({subset: [v1, v5, v6]})
            hc_tm_combiner_results.update({subset: [v2, v7, v8]})
            cad_combiner_results.update({subset: [v3, v9, v10]})
            cad_tm_combiner_results.update({subset: [v4, v11, v12]})


# Select n top 
top_n = 1
# Sort the results based on performance metric

# CAD results
results_list = list(cad_combiner_results.items())
# sorted using macro F1
cad_sorted_results_list = sorted(results_list, key = lambda x: x[1][1], reverse=True)
log_content("\nMLT performance in Macro F1 scores order on CAD test")
for result in cad_sorted_results_list:
    log_content(result)

results_list = list(cad_tm_combiner_results.items())
# sorted using macro F1
cad_tm_sorted_results_list = sorted(results_list, key = lambda x: x[1][1], reverse=True)
log_content("\nMLT-plus-TM performance in Macro F1 scores order on CAD test")
for result in cad_tm_sorted_results_list:
    log_content(result)

# HC results
results_list = list(hc_combiner_results.items())
# sorted using macro F1
hc_sorted_results_list = sorted(results_list, key = lambda x: x[1][1], reverse=True)
log_content("MLT performance in Macro F1 scores order on HateCheck")
for result in hc_sorted_results_list:
    log_content(result)

results_list = list(hc_tm_combiner_results.items())
# sorted using macro F1
hc_tm_sorted_results_list = sorted(results_list, key = lambda x: x[1][1], reverse=True)
log_content("\nMLT-plus-TM performance in Macro F1 scores order on HateCheck")
for result in hc_tm_sorted_results_list:
    log_content(result)

# CAD results
results_list = list(cad_combiner_results.items())
# sorted using accuracy + macro F1
cad_sorted_results_list = sorted(results_list, key = lambda x: x[1][0], reverse=True)
log_content("\nMLT performance in Accuracy + Macro F1 scores order on CAD test")
for result in cad_sorted_results_list:
    log_content(result)

results_list = list(cad_tm_combiner_results.items())
# sorted using accuracy + macro F1
cad_tm_sorted_results_list = sorted(results_list, key = lambda x: x[1][0], reverse=True)
log_content("\nMLT-plus-TM performance in Accuracy + Macro F1 scores order on CAD test")
for result in cad_tm_sorted_results_list:
    log_content(result)

    
# HC results
results_list = list(hc_combiner_results.items())
# sorted using accuracy + macro F1
hc_sorted_results_list = sorted(results_list, key = lambda x: x[1][0], reverse=True)
log_content("\nMLT performance in Accuracy + Macro F1 scores order on HateCheck")
for result in hc_sorted_results_list:
    log_content(result)


results_list = list(hc_tm_combiner_results.items())
# sorted using accuracy + macro F1
hc_tm_sorted_results_list = sorted(results_list, key = lambda x: x[1][0], reverse=True)
log_content("\nMLT-plus-TM performance in Accuracy + Macro F1 scores order on HateCheck")
for result in hc_tm_sorted_results_list:
    log_content(result)


for model in models:
    # results for all individual runs
    results = globals() [f"{model}_cad_results"]
    hc_results = globals() [f"{model}_hc_results"]
    log_content("CAD Model {} per category performance:".format(model_dic[model]))
    category_idx = 0.0
    for category in labels:
        current_recalls = [results[i][0][0].get(str(category_idx)).get('recall')                 for i in range(len(results))]
        current_precisions = [results[i][0][0].get(str(category_idx)).get('precision')                 for i in range(len(results))]
        current_f1s = [results[i][0][0].get(str(category_idx)).get('f1-score')                 for i in range(len(results))]
        log_content('{0} recall: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_recalls),                std(current_recalls), len(current_recalls)))
        log_content('{0} precisions: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_precisions),                std(current_precisions), len(current_precisions)))
        log_content('{0} macro f1: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_f1s),                std(current_f1s), len(current_f1s)))
        category_idx = category_idx + 1
    log_content("\n")    
    log_content("HateCheck Model {} per category performance:".format(model_dic[model]))
    category_idx = 0.0
    for category in labels:
        current_recalls = [hc_results[i][0][0].get(str(category_idx)).get('recall')                 for i in range(len(results))]
        current_precisions = [hc_results[i][0][0].get(str(category_idx)).get('precision')                 for i in range(len(results))]
        current_f1s = [hc_results[i][0][0].get(str(category_idx)).get('f1-score')                 for i in range(len(results))]
        log_content('{0} recall: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_recalls),                std(current_recalls), len(current_recalls)))
        log_content('{0} precisions: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_precisions),                std(current_precisions), len(current_precisions)))
        log_content('{0} macro f1: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_f1s),                std(current_f1s), len(current_f1s)))
        category_idx = category_idx + 1   
    log_content("\n")

write_to_file()