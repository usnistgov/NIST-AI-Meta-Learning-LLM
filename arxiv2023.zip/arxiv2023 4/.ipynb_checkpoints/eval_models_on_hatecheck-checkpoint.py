#!/usr/bin/env python
# coding: utf-8

# EVALUATING MODELS ON HATECHECK, BERT models, commercial models, our individual models, our MLT models, and our MLT-plus-TM models.

# Initialise relevant packages

# Basics
import pandas as pd
import numpy as np
import glob

# Evaluation
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, classification_report

## Data locations
base_dir = './data/'

# Individual model data locations
bi_prefix = 'bi/'
bert_dir = "./bert/" + bi_prefix
bertweet_dir = "./btweet/" + bi_prefix
bigbird_dir = "./bigbird/" + bi_prefix
bloom_dir = "./bloom/" + bi_prefix
xlnet_dir = "./xlnet/" + bi_prefix

mlt_dir = './mlt_pred_hc/'
mlt_tm_dir = './mlt_tm_pred_hc/'

## Individual models participating combiners
model_dic = {
    'm1': "bigbird",
    'm2': "bert",
    'm3': "bertweet",
    "m4": "bloom",
    "m5": "xlnet"
}

## Individual model data locations
model_locs = {
    'm1': bigbird_dir,
    'm2': bert_dir,
    'm3': bertweet_dir,
    "m4": bloom_dir,
    "m5": xlnet_dir
}
models = ['m1', 'm2', 'm3', 'm4', 'm5']
model_names = list(model_dic.values())
model_names = [x.upper() for x in model_names]


# non-hateful column name is 0, hateful column name is 1
ht_column, nht_column = '1', '0'
labels = ['non_hateful', 'hateful']

prob_file_pattern = '_prob'
hc_file_pattern = '_hc'
csv_file_pattern = '*.csv'


# Global content holder
contents = list()


## Display and log a content
def log_content(content):
    contents.append(content)
    if isinstance(content, list):
        for i in content:
            print(i)
    else:
        print(content)


# Load individual model pred probs
data_dic = {} # file name as key, df_data as value
dirs = list() # individual model folders
content = "Participated models are {}".format(model_names)
log_content(content)

# load test suite
hatecheck_df = pd.read_csv('./hateCheck_data/hatecheck_final_ACL.csv', index_col=0)


## Load Model Results
# Load all predicted probs
for model in models:
        dirs.append(model_locs.get(model))
i = 0
for directory in dirs:
    for file_name in sorted(glob.glob(directory + csv_file_pattern)):
        if (hc_file_pattern + prob_file_pattern) in file_name:
            df_data = pd.read_csv(file_name)
            pred = np.round(df_data[['1',]])
            df_pred = pd.DataFrame(pred)
            df_pred['1'] = df_pred['1'].replace(1.0,'hateful')
            df_pred['1'] = df_pred['1'].replace(0.0,'non-hateful')
            col_name = 'pred_{}'.format(model_names[i])
            df_pred.rename(columns = {'1':col_name}, inplace = True)
            df_pred['case_id'] = hatecheck_df['case_id']
            data_dic.update({model_names[i]: df_pred})
            i = i + 1
            break # only load one run from each individual model
        
# load results
results = {}
model_b_d = "B-D"
model_b_f = "B-F"
df_berts = pd.DataFrame(pd.read_pickle('./hateCheck_data/results_BERT_weighted_ACL.pkl'))
df_berts.rename(columns={"pred_BERT_davidson2017_weighted": "pred_"+model_b_d,                         "pred_BERT_founta2018_weighted": "pred_"+model_b_f}, inplace=True)
results['B-D-F'] = df_berts

df_google = pd.DataFrame(pd.read_pickle('./hateCheck_data/results_commercial_models_ACL.pkl'))
model_google = "Google-P"
df_google.rename(columns={"pred_perspective":"pred_"+model_google}, inplace=True)
results['commercial'] = df_google

for name in model_names:
    results.update({name: data_dic.get(name)})


# set of models to evaluate
models_eval = [model_b_d, model_b_f, model_google]
for name in model_names:
    models_eval.append(name)

#Load MLT and MLT-plus-TM predictions and add them to the results, and model_eval. 
# 32 runs in total.
# run_num: number of runs to display
run_num = 3 
mlt_preds = list()
mlt_tm_preds = list()
for i in range(run_num):
    mlt_file_name = mlt_dir + "mlt_pred_hc_{}.csv".format(str(i+1))
    mlt_tm_file_name = mlt_tm_dir + "mlt_tm_pred_hc_{}.csv".format(str(i+1))
    mlt_pred = pd.read_csv(mlt_file_name, index_col=False)
    model_name = 'MLT_{}'.format(str(i+1))
    col_name = "pred_" + model_name
    df_mlt = pd.DataFrame(mlt_pred.iloc[:,1]).        replace({1: 'hateful', 0: 'non-hateful'}).rename(columns={"0": col_name})
    df_mlt['case_id'] = hatecheck_df['case_id']
    results[model_name] = df_mlt
    models_eval.append(model_name)
    mlt_tm_pred = pd.read_csv(mlt_tm_file_name, index_col=False)
    model_name = 'MLT-plus-TM_{}'.format(str(i+1))
    col_name = "pred_" +  model_name
    df_mlt_tm = pd.DataFrame(mlt_tm_pred.iloc[:,1]).        replace({1: 'hateful', 0: 'non-hateful'}).rename(columns={"0": col_name})
    df_mlt_tm['case_id'] = hatecheck_df['case_id']
    models_eval.append(model_name)
    results[model_name] = df_mlt_tm


## Merge Model Results
# merge with hatecheck df
for model in results:
    hatecheck_df = hatecheck_df.merge(results[model], how = 'left', on = 'case_id')


# ## Compute Accuracy by Functionality across Models

# write data to func_accuracy_dict 
func_accuracy_dict = {}

for m in models_eval:
    func_accuracy_dict[m] = []
    for func in pd.unique(hatecheck_df.functionality):
        n_cases = hatecheck_df[hatecheck_df.functionality==func].shape[0]
        n_correct = hatecheck_df[(hatecheck_df.functionality==func)&(hatecheck_df['label_gold']==hatecheck_df['pred_{}'.format(m)])].shape[0]
        func_accuracy_dict[m].append('{:.1%}'.format(n_correct/n_cases))
    
    # convert list to series
    func_accuracy_dict[m] = pd.Series(func_accuracy_dict[m])
    func_accuracy_dict[m].name = m

# create df from dict
func_accuracy_df = pd.Series(pd.unique(hatecheck_df.functionality))
func_accuracy_df.name = 'Functionality'

for arc_data in func_accuracy_dict:
    func_accuracy_df = pd.concat([func_accuracy_df, pd.Series(func_accuracy_dict[arc_data])], axis =1)

func_accuracy_df

file_path = 'hatecheck_29_func_acc_3_runs.csv'
func_accuracy_df.to_csv(file_path, encoding='utf8')


## Compute Classification Reports for Each Model 
# print classification reports for each classifier
for m in models_eval:
        print(m.upper())
        print(classification_report(hatecheck_df.label_gold.replace({'hateful': 1, 'non-hateful':0}),
                    hatecheck_df['pred_{}'.format(m)].astype('object').replace({'hateful': 1, 'non-hateful': 0}),
                    target_names = ['non-hateful','hateful'],
                    digits=4))
        print()

print('ACCURACY \n')
for m in models_eval:
    print(m)
    for lab in ['hateful', 'non-hateful']:
        n_cases = hatecheck_df[hatecheck_df.label_gold==lab].shape[0]
        n_correct = hatecheck_df[(hatecheck_df.label_gold==lab) & (hatecheck_df['label_gold']==hatecheck_df['pred_{}'.format(m)])].shape[0]
        print('{}: {:.1%}:'.format(lab, n_correct/n_cases))
    print('TOTAL: {:.1%}'.format(hatecheck_df[(hatecheck_df['label_gold']==hatecheck_df['pred_{}'.format(m)])].shape[0]/hatecheck_df.shape[0]))
    print()


# ## Performance for Reclaimed Slurs
hatecheck_df[(hatecheck_df.functionality == 'slur_reclaimed_nh')].groupby('focus_lemma').case_id.count().keys()

print('ACCURACY')
for m in models_eval:
    #print(m.upper())
    print(m)
    for slur in ['nigga', 'fag', 'faggot', 'queer', 'bitch']:
        n_total = hatecheck_df[(hatecheck_df.functionality == 'slur_reclaimed_nh')&
                                (hatecheck_df.focus_lemma==slur)].shape[0]
        n_correct = hatecheck_df[(hatecheck_df.functionality == 'slur_reclaimed_nh')&
                                  (hatecheck_df['pred_{}'.format(m)]==hatecheck_df.label_gold)&
                                  (hatecheck_df.focus_lemma==slur)].shape[0]
        print(n_total)
        print(slur, ': {:.1%}'.format(n_correct/n_total))
    print()
    


## Performance Across Cases by Target Identity
# create df with only template cases --> number of cases for each identity should be balanced
templ_cases_df = hatecheck_df[hatecheck_df.case_templ.str.contains('IDENTITY')].copy()

templ_cases_df.groupby(templ_cases_df.target_ident).case_id.count()

# write data to dict
ident_accuracy_dict = {}

for m in models_eval:
    ident_accuracy_dict[m] = []
    for ident in pd.unique(templ_cases_df.target_ident):
        n_cases = templ_cases_df[templ_cases_df.target_ident==ident].shape[0]
        n_correct = templ_cases_df[(templ_cases_df.target_ident==ident)&(templ_cases_df['label_gold']==templ_cases_df['pred_{}'.format(m)])].shape[0]
        ident_accuracy_dict[m].append('{:.1%}'.format(n_correct/n_cases))
    ident_accuracy_dict[m] = pd.Series(ident_accuracy_dict[m])
    ident_accuracy_dict[m].name = m

# create df from dict
ident_accuracy_df = pd.Series(pd.unique(templ_cases_df.target_ident))
ident_accuracy_df.name = 'target_ident'

for arc_data in ident_accuracy_dict:
    ident_accuracy_df = pd.concat([ident_accuracy_df, pd.Series(ident_accuracy_dict[arc_data])], axis =1)

ident_accuracy_df

file_path = 'hatecheck_target_acc_3_runs.csv'
ident_accuracy_df.to_csv(file_path, encoding='utf8')

